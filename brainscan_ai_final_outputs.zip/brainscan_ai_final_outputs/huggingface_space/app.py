
import json
import numpy as np
import streamlit as st
from PIL import Image
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

st.set_page_config(page_title='BrainScan AI', layout='centered')
with open('model_metadata.json') as f: META = json.load(f)
IMG_SIZE = META['img_size']; MODEL_NAME = META['model_name']; CLASS_ORDER = META['class_order']; CLASS_PRETTY = META['class_pretty']

st.title('BrainScan AI')
st.warning('Educational/research prototype only. Not for clinical diagnosis. Do not use this app for medical decisions.')

def build_compact_cnn():
    inp = keras.Input((IMG_SIZE, IMG_SIZE, 3), name='mri_image')
    x = layers.Rescaling(1/255.)(inp)
    for f in [32, 64, 128, 192]:
        x = layers.Conv2D(f, 3, padding='same', use_bias=False)(x); x = layers.BatchNormalization()(x); x = layers.Activation('relu')(x)
        x = layers.Conv2D(f, 3, padding='same', use_bias=False)(x); x = layers.BatchNormalization()(x); x = layers.Activation('relu')(x)
        x = layers.MaxPooling2D()(x); x = layers.Dropout(.15)(x)
    x = layers.GlobalAveragePooling2D()(x); x = layers.Dense(256, activation='relu')(x); x = layers.BatchNormalization()(x); x = layers.Dropout(.35)(x)
    return keras.Model(inp, layers.Dense(4, activation='softmax', name='severity_probability')(x), name='CompactCNN')

def build_transfer(name):
    if name == 'MobileNetV2': preprocess, backbone = tf.keras.applications.mobilenet_v2.preprocess_input, tf.keras.applications.MobileNetV2(include_top=False, weights=None, input_shape=(IMG_SIZE,IMG_SIZE,3))
    elif name == 'ResNet50': preprocess, backbone = tf.keras.applications.resnet50.preprocess_input, tf.keras.applications.ResNet50(include_top=False, weights=None, input_shape=(IMG_SIZE,IMG_SIZE,3))
    else: preprocess, backbone = tf.keras.applications.efficientnet.preprocess_input, tf.keras.applications.EfficientNetB0(include_top=False, weights=None, input_shape=(IMG_SIZE,IMG_SIZE,3))
    backbone._name = name + '_backbone'
    inp = keras.Input((IMG_SIZE, IMG_SIZE, 3), name='mri_image')
    x = layers.Lambda(preprocess, name=name + '_preprocess')(inp)
    x = backbone(x, training=False); x = layers.GlobalAveragePooling2D()(x); x = layers.BatchNormalization()(x)
    x = layers.Dense(256, activation='relu')(x); x = layers.Dropout(.40)(x); x = layers.Dense(128, activation='relu')(x); x = layers.Dropout(.25)(x)
    return keras.Model(inp, layers.Dense(4, activation='softmax', name='severity_probability')(x), name=name)

@st.cache_resource
def load_model():
    model = build_compact_cnn() if MODEL_NAME == 'CompactCNN' else build_transfer(MODEL_NAME)
    model.load_weights('model.weights.h5')
    return model

model = load_model()
up = st.file_uploader('Upload sample MRI JPG/PNG for demonstration only', type=['jpg','jpeg','png'])
if up:
    img = Image.open(up).convert('RGB').resize((IMG_SIZE, IMG_SIZE))
    arr = np.expand_dims(np.array(img).astype('float32'), 0)
    probs = model.predict(arr, verbose=0)[0]
    pred = int(np.argmax(probs))
    st.image(img, caption='Input image', use_column_width=True)
    st.subheader('Prediction')
    st.write(f"Predicted class: **{CLASS_PRETTY[CLASS_ORDER[pred]]}**")
    st.write(f"Confidence: **{probs[pred]:.2%}**")
    st.bar_chart({CLASS_PRETTY[CLASS_ORDER[i]]: float(probs[i]) for i in range(4)})
else:
    st.info('Upload a sample image to test the prototype.')
