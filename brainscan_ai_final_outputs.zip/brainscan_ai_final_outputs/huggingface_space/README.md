# BrainScan AI

Educational/research prototype only. Not for clinical diagnosis.
